# QuickTap Shortcuts — Android starter project

A native Kotlin Android prototype for a draggable floating shortcut bubble with Copy, Paste, and Select All actions.

## Open and run
1. Install Android Studio (current stable) on a computer.
2. Open this `QuickTapShortcut` folder as an existing Android Studio project.
3. Allow Gradle to sync. This project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, and min SDK 26 (Android 8.0).
4. Run on an Android phone.
5. Open QuickTap Shortcuts. Tap **Allow floating button** and allow display over other apps.
6. Tap **Enable shortcut service**. In Android Accessibility settings, enable **QuickTap Shortcut Actions** and approve the system warning.
7. Return to another app. Tap the floating blue Q button, then choose Copy, Paste, or Select All.

## Important limitations
- This is a starter prototype, not a tested/release-ready APK. Build it in Android Studio and test on target devices.
- Android apps expose different accessibility actions. Copy/Paste/Select All may not work in every app, secure field, browser, or custom text editor.
- It does not inject literal Ctrl-key events. It asks the currently focused app's accessibility node to perform the corresponding supported action.
- Android permission names, battery restrictions, and overlay behavior vary by OS version and manufacturer. Users must explicitly enable overlay and accessibility permissions.
- Accessibility service access is powerful. Explain its behavior clearly to users, collect no data, and never use it to read or transmit screen contents.
