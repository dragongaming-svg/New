package com.quicktap.shortcut

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "QuickTap Shortcuts"
            textSize = 26f
            setTextColor(0xFF172033.toInt())
        }, match(ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(TextView(this).apply {
            text = "Use a floating button to access Copy, Paste and Select All. Android requires you to enable the accessibility service and allow display over other apps."
            textSize = 16f
            setPadding(0, 20, 0, 24)
        })
        root.addView(actionButton("1. Allow floating button", "Overlay permission") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(actionButton("2. Enable shortcut service", "Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(TextView(this).apply {
            text = "After enabling both permissions, return to any app and use the floating blue button. Some apps do not expose copy/paste actions, so support can vary."
            textSize = 14f
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
    }

    private fun match(height: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)

    private fun actionButton(title: String, desc: String, action: () -> Unit) = Button(this).apply {
        text = title
        contentDescription = desc
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = 12
        }
    }
}
