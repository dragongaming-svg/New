package com.quicktap.shortcut

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class ShortcutAccessibilityService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var menu: LinearLayout? = null
    private var menuParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var downX = 0
    private var downY = 0
    private var startX = 0
    private var startY = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) { }
    override fun onInterrupt() { }

    override fun onDestroy() {
        removeViews()
        super.onDestroy()
    }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "Q"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF2563EB.toInt())
                setStroke(2, 0xFFFFFFFF.toInt())
            }
            elevation = 8f
            setOnClickListener { toggleMenu() }
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX.toInt(); downY = e.rawY.toInt()
                        bubbleParams?.let { startX = it.x; startY = it.y }
                        false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX.toInt() - downX
                        val dy = e.rawY.toInt() - downY
                        if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) {
                            bubbleParams?.let { p -> p.x = startX + dx; p.y = startY + dy; wm.updateViewLayout(this, p) }
                            true
                        } else false
                    }
                    else -> false
                }
            }
        }
        val p = WindowManager.LayoutParams(58, 58, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18; y = 260
        }
        try { wm.addView(b, p); bubble = b; bubbleParams = p } catch (_: Exception) {
            Toast.makeText(this, "Allow display over other apps for QuickTap", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleMenu() {
        if (menu != null) { removeMenu(); return }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            background = GradientDrawable().apply {
                setColor(0xFFF7F9FC.toInt())
                cornerRadius = 28f
                setStroke(2, 0xFFD7DEEA.toInt())
            }
            elevation = 12f
        }
        panel.addView(TextView(this).apply { text = "Quick Shortcuts"; textSize = 16f; setTextColor(0xFF172033.toInt()); setPadding(8, 4, 8, 10) })
        panel.addView(menuButton("Copy  ·  Ctrl+C") { performTextAction(Action.COPY) })
        panel.addView(menuButton("Paste  ·  Ctrl+V") { performTextAction(Action.PASTE) })
        panel.addView(menuButton("Select All  ·  Ctrl+A") { performTextAction(Action.SELECT_ALL) })
        panel.addView(menuButton("Close") { removeMenu() })
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18; y = 330
        }
        try { wm.addView(panel, p); menu = panel; menuParams = p } catch (_: Exception) { }
    }

    private fun menuButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(240, 52).apply { bottomMargin = 4 }
    }

    private enum class Action { COPY, PASTE, SELECT_ALL }

    private fun performTextAction(action: Action) {
        val root = rootInActiveWindow
        if (root == null) { toast("No active app found"); removeMenu(); return }
        val node = findBestNode(root, action)
        val success = try {
            when (action) {
                Action.COPY -> node?.performAction(AccessibilityNodeInfo.ACTION_COPY) ?: false
                Action.PASTE -> node?.performAction(AccessibilityNodeInfo.ACTION_PASTE) ?: false
                Action.SELECT_ALL -> selectAll(node)
            }
        } catch (_: Exception) { false }
        toast(if (success) "${action.name.replace('_', ' ')} action sent" else "This app or field may not support this action")
        removeMenu()
    }

    private fun findBestNode(node: AccessibilityNodeInfo, action: Action): AccessibilityNodeInfo? {
        val editable = node.isEditable
        val focused = node.isFocused || node.isAccessibilityFocused
        val useful = when (action) {
            Action.PASTE -> editable
            Action.COPY -> editable || node.isTextSelectable
            Action.SELECT_ALL -> editable || node.isTextSelectable
        }
        if (useful && focused) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findBestNode(child, action)
            child.recycle()
            if (result != null) return result
        }
        if (useful) return AccessibilityNodeInfo.obtain(node)
        return null
    }

    private fun selectAll(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        if (node.isEditable) {
            val textLength = node.text?.length ?: 0
            val args = android.os.Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, textLength)
            }
            if (node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, args)) return true
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SELECT)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun removeMenu() { menu?.let { try { wm.removeView(it) } catch (_: Exception) { } }; menu = null; menuParams = null }
    private fun removeViews() { removeMenu(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) { } }; bubble = null }
}
